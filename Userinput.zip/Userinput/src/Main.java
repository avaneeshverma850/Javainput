import java.sql.SQLOutput;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        //Simple Interest
      /* System.out.println("Enter Principal,interest,Time");
        float si;
        int Principal=sc.nextInt();
        float Interest= sc.nextFloat();
        int time= sc.nextInt();
        si=(Principal*Interest*time)/100;
        System.out.println("Simple interest is:"+si);*/
        //Area of Rectangle
        /*System.out.println("Enter Length and Breadth");
        int Area;
        int Length=sc.nextInt();
        int Breadth=sc.nextInt();
        Area=Length*Breadth;
        System.out.println("Area of Rectangle is:"+Area);*/
        //Average of three number
        /*System.out.println("Enter three numbers");
        float Avg;
        int a=sc.nextInt();
        int b=sc.nextInt();
        int c=sc.nextInt();
        Avg=(a+b+c)/3;
        System.out.println("Average of three number is:"+Avg);*/
        //Volume of a cuboid
        /*float Volume;
        System.out.println("Enter length,breadth,height");
        int L=sc.nextInt();
        int B=sc.nextInt();
        int H=sc.nextInt();
        Volume=L*B*H;
        System.out.println("Voulume of cuboid is:",+Volume);*/
        //Calculate x power y
        System.out.println("Enter x and y");
        int x=sc.nextInt();
        int y= sc.nextInt();
        double Res=Math.pow(x,y);
        System.out.println("Result:"+Res);



    }
}